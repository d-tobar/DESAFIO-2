﻿Console.BackgroundColor = ConsoleColor.White;
Console.ForegroundColor = ConsoleColor.Black;
Console.Clear(); 
Console.SetWindowSize(80, 25);
double a, b, resultado, opcion;
while (true)
{
    Console.WriteLine("Digite el primer numero");
    a = double.Parse(Console.ReadLine());
    Console.Clear();
    Console.WriteLine("Digite el segundo numero");
    b = double.Parse(Console.ReadLine());
    Console.Clear();

    while (true)
    {
        Console.Clear();
        resultado = 0;
        Console.WriteLine("Que operacion desea realizar");
        Console.WriteLine("1- sumar");
        Console.WriteLine("2- restar");
        Console.WriteLine("3- multiplicar");
        Console.WriteLine("4- dividir");
        Console.WriteLine("5- salir del programa");

        opcion = double.Parse(Console.ReadLine());




         switch (opcion)
        {
            case 1:

                resultado = a + b;
                Console.WriteLine("resultado");
                Console.WriteLine(resultado);
                Console.WriteLine("");
                Console.WriteLine("Precione cualquier tecla para regresar...");
                Console.ReadKey();
                break;

            case 2:
                resultado = a - b;
                Console.WriteLine("resultado");
                Console.WriteLine(resultado);
                Console.WriteLine("");
                Console.WriteLine("Precione cualquier tecla para regresar...");
                Console.ReadKey();
                break;

            case 3:
                resultado = a * b;
                Console.WriteLine("resultado");
                Console.WriteLine(resultado);
                Console.WriteLine("");
                Console.WriteLine("Precione cualquier tecla para regresar...");
                Console.ReadKey();
                break;

            case 4:
                resultado = a / b;
                Console.WriteLine("resultado");
                Console.WriteLine(resultado);
                Console.WriteLine("");
                Console.WriteLine("Precione cualquier tecla para regresar...");
                Console.ReadKey();
                break;

            case 5:
                Console.WriteLine("Fin del programa...");
                break;

        }
        if (opcion == 5) break;
    }
    if (opcion == 5) break;
}
﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);
        double[] alturas = new double[6];
        double promedio = 0, Altas = 0, Bajas = 0;

        for (int i = 0; i < 6; i++)
        {
            Console.Write("Ingrese la altura " + (i + 1) + ":");
            alturas[i] = Double.Parse(Console.ReadLine());
            Console.Clear();
        }
        Console.Clear();

        for (int i = 0; i < 6; i++)
        {
            promedio += alturas[i];
        }

        promedio = promedio / 6;

        for (int i = 0; i < 6; i++)
        {
            if (alturas[i] > promedio)
            {
                Altas++;
            }
            else if (alturas[i] < promedio)
            {
                Bajas++;
            }
        }

        Console.WriteLine("El promedio es...");
        Console.WriteLine(promedio);
        Console.WriteLine("La cantidad de más altas son...");
        Console.WriteLine(Altas);
        Console.WriteLine("La cantidad de más bajas son...");
        Console.WriteLine(Bajas);


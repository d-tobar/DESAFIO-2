﻿using System;

class Program
{
    static void Main()
    {
      
         Console.Clear();
        double a = 0, b = 0, opcion = 0;

        while (true) 
        {
            
            Console.WriteLine("DIGITE EL PRIMERO NUMERO");
            a = double.Parse(Console.ReadLine());
            Console.WriteLine("DIGITE EL SEGUNDO NUMERO");
            b = double.Parse(Console.ReadLine());
            Console.Clear();

            while (true) 
            {
                
                Console.Clear();
                Console.WriteLine("ELIJA UNA DE LAS SIGUIENTES OPCIONES");
                Console.WriteLine("1- RANGO DE NÚMEROS DIVISIBLES POR 3");
                Console.WriteLine("2- RANGO DE NÚMEROS DIVISIBLES POR 7");
                Console.WriteLine("3- VOLVER A DIGITAR EL RANGO");
                Console.WriteLine("4- SALIR DEL PROGRAMA");
                

                opcion = double.Parse(Console.ReadLine());

                switch (opcion)
                {
                    case 1:
                        Console.Clear();
                        Console.WriteLine("Opcion 1: Números divisibles por 3:");
                        for (double i = a; i <= b; i++)
                        {
                            if (i % 3 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                        Console.WriteLine("precione cualquier tecla para continuar");
                        Console.ReadKey();
                        break;

                    case 2:
                        Console.Clear();
                        Console.WriteLine("Opcion 2: multiplos de 7:");
                        for (double i = a; i <= b; i++)
                        {
                            if (i % 7 == 0)
                            {
                                Console.WriteLine(i);
                            }
                        }
                        Console.WriteLine("precione cualquier tecla para continuar");
                        Console.ReadKey();
                        break;

                    case 3:
                        Console.WriteLine("Reiniciando el rango de numeros...");
                        break; 

                    case 4:
                        Console.WriteLine("Fin del programa...");

                        break;
                    default:
                        Console.WriteLine("Valores no correctos.");
                        break;
                }

                if (opcion == 3) break;
                
                if (opcion == 4) break; 
                
            } 
            if (opcion == 4) break;

        }
    }
}

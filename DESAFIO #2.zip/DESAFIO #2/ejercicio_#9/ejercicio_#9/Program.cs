﻿            Console.BackgroundColor = ConsoleColor.White;
            Console.Clear();
            Console.SetWindowSize(80, 25);
double[] presion = new double[15];
        int alta = 0;
        double suma = 0;

        for (int i = 0; i < 15; i++)
        {
            Console.Write("Ingrese la presión del día " + (i + 1) + ": ");
            presion[i] = double.Parse(Console.ReadLine());
            suma += presion[i];

            if (presion[i] > 130)
            {
                alta++;
            }
        }

        double promedio = Math.Round(suma / 15, 2);



        Console.WriteLine("Presión arterial en los ultimos 15 dias:");
        for (int i = 0; i < 15; i++)
        {
           
            if (presion[i] > 130)
            {
                Console.WriteLine("Día " + (i + 1) + ": " + presion[i] + " (Alta)");
            }
            
            else 
            {
                Console.WriteLine("Día " + (i + 1) + ": " + presion[i]);
            }
        }

        Console.WriteLine("Promedio de presión arterial: " + promedio);
        Console.WriteLine("Días con la presion alta: " + alta);

        if (alta >= 11)
        {
            Console.WriteLine("¡ALERTA! Se necesita intervención médica.");
        }
    
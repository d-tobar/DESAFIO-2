﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);
        Random random = new Random();
        int seguir = 1;

        while (seguir == 1)
        {
            int numero_adiv = random.Next(1, 101);
            int intentos = 10;

            while (intentos > 0)
            {
                Console.WriteLine("Adivina el número del 1 al 100: ");
                Console.WriteLine("Intentos restantes: " + intentos);
                int intento = int.Parse(Console.ReadLine());

                if (intento == numero_adiv)
                {
                    Console.WriteLine("Ganaste");
                    break;
                }
                else if (intento < numero_adiv)
                {
                    Console.WriteLine("El número es mayor.");
                }
                else
                {
                    Console.WriteLine("El número es menor.");
                }

                intentos--;
                Console.ReadKey();
                Console.Clear();
            }

            if (intentos == 0)
            {
                Console.WriteLine("Perdiste, el número era " + numero_adiv);
            }

            Console.WriteLine("¿Jugar de nuevo? ");
            Console.WriteLine("1- si ");
            Console.WriteLine("2- no");

            seguir = int.Parse(Console.ReadLine());
        }
    
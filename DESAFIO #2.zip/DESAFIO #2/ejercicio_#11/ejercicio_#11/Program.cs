﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);
        List<string> nombres = new List<string>();
        List<DateTime> fechas = new List<DateTime>();
        int opcion = 1;

        while (opcion ==1)
        {
            Console.WriteLine("Ingrese el nombre:");
            nombres.Add(Console.ReadLine()); 
            Console.WriteLine("Ingrese la fecha de nacimiento (dd/mm/yyyy):");
            fechas.Add(DateTime.Parse(Console.ReadLine()));  

            Console.WriteLine("¿Desea ingresar más personas?");
            Console.WriteLine("1- si");
            Console.WriteLine("2- no");
             opcion = int.Parse(Console.ReadLine());
            if (opcion == 1)
                break;  
        }

        
        DateTime hoy = DateTime.Today;
        for (int i = 0; i < nombres.Count; i++)
        {
            if (fechas[i].Month == hoy.Month && fechas[i].Day == hoy.Day)
            {
                int edad = hoy.Year - fechas[i].Year;
                if (hoy < fechas[i].AddYears(edad)) edad--;
                Console.WriteLine($"{nombres[i]} está cumpliendo años.");
            }
        }

       
        Console.WriteLine("Ingrese una fecha (dd/mm):");
        string fechaInput = Console.ReadLine();
        string[] fechaParts = fechaInput.Split('/');
        int dia = int.Parse(fechaParts[0]);
        int mes = int.Parse(fechaParts[1]);

        for (int i = 0; i < nombres.Count; i++)
        {
            if (fechas[i].Day == dia && fechas[i].Month == mes)
            {
                Console.WriteLine($"{nombres[i]} cumple años el {dia}/{mes}.");
            }
        }
    

﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);
        string[] palabrasSecretas = { "don bosco", "ingeniero", "licuadora", "pelota", "elefante", "pez" };
        string[] pistas = {
            "Estudias en ella",
            "profesion",
            "Es un electrodomestico",
            "obejto redondo",
            "Es un anmal grande",
            "Es un animal pequeño"
        };
        Random random = new Random();
        string palabraSecreta = palabrasSecretas[random.Next(0, palabrasSecretas.Length)];
        string palabraAdivinada = new string('_', palabraSecreta.Length);
        int intentosRestantes = 6;
        string letrasIncorrectas = "";
        int pistaIndex = 0;

        
        while (intentosRestantes > 0)
        {
            Console.Clear();
            Console.WriteLine($"Palabra: {palabraAdivinada}");
            Console.WriteLine($"Letras incorrectas: {letrasIncorrectas}");
            Console.WriteLine($"Intentos restantes: {intentosRestantes}");

           
            if (intentosRestantes < 6 && pistaIndex < pistas.Length)
            {
                Console.WriteLine($"Pista: {pistas[pistaIndex]}");
                pistaIndex++;
            }

            Console.Write("Ingresa una letra: ");
            char letra = char.Parse(Console.ReadLine().ToLower());

            if (palabraSecreta.Contains(letra))
            {
                for (int i = 0; i < palabraSecreta.Length; i++)
                {
                    if (palabraSecreta[i] == letra)
                    {
                        palabraAdivinada = palabraAdivinada.Substring(0, i) + letra + palabraAdivinada.Substring(i + 1);
                    }
                }
                if (!palabraAdivinada.Contains('_'))
                {
                    Console.WriteLine("¡Ganaste! La palabra secreta era: " + palabraSecreta);
                    break;
                }
            }
            else
            {
                letrasIncorrectas += letra + " ";
                intentosRestantes--;
            }

            if (intentosRestantes == 0)
            {
                Console.WriteLine("Perdiste. La palabra secreta era: " + palabraSecreta);
            }
        }


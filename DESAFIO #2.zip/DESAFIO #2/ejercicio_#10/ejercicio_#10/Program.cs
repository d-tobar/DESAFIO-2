﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);
        int seguir = 1;
        while (seguir == 1)
        {
            int[,] A = new int[4, 4];
            int[,] B = new int[4, 4];
            int[,] C = new int[4, 4];

            Console.WriteLine("Ingrese los valores de la primera matriz:");
            for (int i = 0; i < 4; i++)
                for (int o = 0; o < 4; o++)
                    A[i, o] = int.Parse(Console.ReadLine());
            Console.Clear();

            Console.WriteLine("Ingrese los valores de la segunda matriz:");
            for (int i = 0; i < 4; i++)
                for (int o = 0; o < 4; o++)
                    B[i, o] = int.Parse(Console.ReadLine());
            Console.Clear();

            for (int i = 0; i < 4; i++)
                for (int o = 0; o < 4; o++)
                    for (int k = 0; k < 4; k++)
                        C[i, o] += A[i, k] * B[k, o];

            Console.WriteLine("Primera matriz:");
            for (int i = 0; i < 4; i++)
            {
                for (int o = 0; o < 4; o++)
                    Console.Write(A[i, o] + " ");
                Console.WriteLine();
            }

            Console.WriteLine("Segunda matriz:");
            for (int i = 0; i < 4; i++)
            {
                for (int o = 0; o < 4; o++)
                    Console.Write(B[i, o] + "\n");
                Console.WriteLine();
            }

            Console.WriteLine("Resultado de la multiplicación:");
            for (int i = 0; i < 4; i++)
            {
                for (int o = 0; o < 4; o++)
                    Console.Write(C[i, o] + "\n");
                Console.WriteLine();
            }

            Console.WriteLine("¿Desea hacer otra multiplicación? (s/n)");
            seguir = int.Parse(Console.ReadLine());
            if (seguir == 1)

            break;
            Console.Clear();
        }
    


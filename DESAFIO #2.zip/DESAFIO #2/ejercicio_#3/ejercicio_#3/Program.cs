﻿Console.BackgroundColor = ConsoleColor.White;
Console.ForegroundColor = ConsoleColor.Black;
Console.Clear();
Console.SetWindowSize(80, 25);

double numeros = 0, cantidad, promedio;

Console.WriteLine("Incerte la cantidad de numeros a provediar...");

while (!double.TryParse(Console.ReadLine(), out cantidad) || cantidad <= 0)
{
    Console.WriteLine("Por favor, ingrese un número entero positivo:");
}

Console.Clear();
for (int i = 1; i <= cantidad; i++)
{
    Console.WriteLine("Incerte los numeros a provediar...");
    while (!double.TryParse(Console.ReadLine(), out numeros))
    {
        Console.WriteLine("Por favor, ingrese un número entero positivo:");
    }
    Console.Clear();
}

promedio = numeros / cantidad;
promedio = Math.Round(promedio, 2);
Console.Clear();

Console.WriteLine("El promedio de los numeros ingresados es...");
Console.WriteLine(promedio);



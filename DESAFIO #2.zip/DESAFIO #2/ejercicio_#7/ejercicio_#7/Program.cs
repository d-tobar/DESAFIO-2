﻿        Console.BackgroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.Black;
        Console.Clear();
        Console.SetWindowSize(80, 25);

        bool[,] sala = new bool[5, 8];
        int fila, butaca;
        double opcion;

        while (true)
        {
            Console.Clear();
            Console.WriteLine("1- Verificar asiento");
            Console.WriteLine("2- Asignar asiento");
            Console.WriteLine("3- Salir");
            opcion = double.Parse(Console.ReadLine());

            switch (opcion)
            {
                case 1:
                    Console.Clear ();
                    Console.Write("Ingrese la fila: ");
                    fila = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese la butaca: ");
                    butaca = int.Parse(Console.ReadLine());

                    if (sala[fila, butaca])
                    { 
                        Console.WriteLine("El asiento está ocupado.");
                        Console.ReadKey();
                    }
                    else
                    {
                        Console.WriteLine("El asiento está disponible.");
                        Console.ReadKey();
                     }
                     break;

                case 2:
                    Console.Clear();
                    Console.Write("Ingrese la fila: ");
                    fila = int.Parse(Console.ReadLine());
                    Console.Write("Ingrese la butaca: ");
                    butaca = int.Parse(Console.ReadLine());

                    if (sala[fila, butaca])
                    { 
                        Console.WriteLine("El asiento  está ocupado.");
                        Console.ReadKey();
                    }       
                     else
                    {
                        sala[fila, butaca] = true;
                        Console.WriteLine("Asiento asignado");
                        Console.ReadKey();
                    }
                    break;

                case 3:
                     Console.Clear();
                     Console.WriteLine("Fin del programa");
                    break;

                default:
                    Console.WriteLine("Opción no válida. Intente nuevamente.");
                    break;
            }
            if (opcion == 3) break;
        }
    
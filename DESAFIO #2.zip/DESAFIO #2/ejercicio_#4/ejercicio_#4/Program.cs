﻿Console.BackgroundColor = ConsoleColor.White;
Console.ForegroundColor = ConsoleColor.Black;
Console.Clear();
Console.SetWindowSize(80, 25);

int cantidad;

        Console.Write("Cuántos alumnos hay? ");
        cantidad = int.Parse(Console.ReadLine());

        string[] nombres = new string[cantidad];
        double[,] notas = new double[cantidad, 3];

        Console.Clear();
        for (int i = 0; i < cantidad; i++)
        {
            Console.Write("Nombre del alumno: ");

            nombres[i] = Console.ReadLine();
            Console.Clear();

            for (int o = 0; o < 3; o++)
            {
                Console.Write("Ingrese la nota: " );
                notas[i, o] = double.Parse(Console.ReadLine());
                Console.Clear();
            }
        }

        for (int i = 0; i < cantidad; i++)
        {
            double suma = 0;
            Console.Write(nombres[i] + "  Notas: ");
            for (int o = 0; o < 3; o++)
            {
                Console.Write(notas[i, o] + ", ");
                suma += notas[i, o];
            }

            double promedio = suma / 3;
            Console.WriteLine(" Promedio: " + promedio);
        }
    

